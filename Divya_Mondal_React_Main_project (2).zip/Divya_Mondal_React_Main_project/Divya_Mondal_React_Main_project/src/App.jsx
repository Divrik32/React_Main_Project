import './App.css'
import AboutUs from './components/AboutUs';
import Blog from './components/Blog';
import Cart from './components/Cart';
import ContactUs from './components/ContactUs';
import Footer from './components/Footer'
import Home from './components/Home'
import Navbar from './layouts/Navbar'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Route, RouterProvider, Routes, createBrowserRouter } from "react-router-dom"
import Shop from './components/Shop';
import Signin from './Auth/Signin';
import Signup from './Auth/Signup';
import { ToastContainer } from 'react-toastify';
import Conditional from './Auth/Conditional';
import Services from './components/Services';
import Root from './layouts/Root';
import AuthRouter from './utils/AuthRouter';
import CreateProduct from './components/Createproduct';
import EditProduct from './components/EditProduct';
import ProductDetails from './components/ProductDetails';


const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      {
        path: "/",
        element: <Conditional />,
      },
      {
        path: "/signin",
        element: <Signin />,
      },
      {
        path: "/signup",
        element: <Signup />,
      },

      {
        element: <AuthRouter />,
        children: [
          {
            path: "/create",
            element: <CreateProduct />,
          },
          {
            path: "/home",
            element: <Home />,
          },
          {
            path: "/shop",
            element: <Shop />,
          },
          {
            path: "/productdetails/:id",
            element: <ProductDetails />,
          },
          {
            path: "/about", 
            element: <AboutUs />,
          },
          {
            path: "/services", 
            element: <Services />,
          },
          {
            path: "/blog", 
            element: <Blog />,
          },
          {
            path: "/contact", 
            element: <ContactUs />,
          },
          {
            path: "/editProduct/:id", 
            element: <EditProduct />,
          },
          {
            path: "/cart", 
            element: <Cart />,
          }
        ],
      },
    ],
  },
]);
function App() {
  return (
<>
<RouterProvider router={router} />
<ToastContainer /></>
  )
}

export default App
