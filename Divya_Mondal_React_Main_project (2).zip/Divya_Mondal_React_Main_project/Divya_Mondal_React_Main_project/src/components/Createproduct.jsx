import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import ApiHandler from "../Api/ApiHandler";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link, useNavigate } from "react-router-dom";
import { Button, TextField, Typography, Box, Paper, Grid } from "@mui/material";

const CreateProduct = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const [img, setImg] = useState(null);

  const { mutate } = useMutation({
    mutationFn: ApiHandler?.createProduct,
    onSuccess: (response) => {
      if (response?.status === 200) {
        toast.success(response?.message, {
          onClose: () => navigate("/shop"),
        });
        queryClient.invalidateQueries({ queryKey: ["products"] });
      } else {
        toast.error(response?.message);
      }
    },
  });

  const onSubmit = (data) => {
    const formData = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    if (img) {
      formData.append("image", img);
    }
    mutate(formData);
  };

  return (
    <>
      <Box sx={{ padding: 4, backgroundColor: "#f5f5f5", minHeight: "100vh" }}>
        <Grid container spacing={2} justifyContent="center">
          <Grid item xs={12} sm={8} md={6}>
            <Link to="/shop" style={{ textDecoration: "none" }}>
              <Button variant="contained" color="secondary" fullWidth>
                View Products List
              </Button>
            </Link>
            <Paper elevation={3} sx={{ padding: 4, marginTop: 3 }}>
              <Typography variant="h4" align="center" color="primary">
                Create Product
              </Typography>
              <form onSubmit={handleSubmit(onSubmit)}>
                <Box sx={{ marginBottom: 2 }}>
                  <TextField
                    fullWidth
                    label="Title"
                    variant="outlined"
                    {...register("title", { required: true })}
                    error={!!errors.title}
                    helperText={errors.title ? "This field is required" : ""}
                  />
                </Box>
                <Box sx={{ marginBottom: 2 }}>
                  <TextField
                    fullWidth
                    label="Description"
                    variant="outlined"
                    multiline
                    rows={3}
                    {...register("description", { required: true })}
                    error={!!errors.description}
                    helperText={errors.description ? "This field is required" : ""}
                  />
                </Box>
                <Box sx={{ marginBottom: 2 }}>
                  <input
                    type="file"
                    onChange={(e) => setImg(e.target.files[0])}
                    accept="image/*"
                    style={{ display: "none" }}
                    id="image-upload"
                  />
                  <label htmlFor="image-upload">
                    <Button variant="contained" component="span" color="primary" fullWidth>
                      Upload Image
                    </Button>
                  </label>
                  {img && (
                    <img
                      style={{ height: "180px", marginTop: "10px" }}
                      src={URL.createObjectURL(img)}
                      alt="Preview"
                      className="upload-img"
                    />
                  )}
                </Box>
                <Button type="submit" variant="contained" color="success" fullWidth>
                  Submit
                </Button>
              </form>
            </Paper>
          </Grid>
        </Grid>
      </Box>
      <ToastContainer />
    </>
  );
};

export default CreateProduct;
