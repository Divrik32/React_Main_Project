import React from 'react';

const Loading = () => {
  return (
    <div className="loading">
      <h2>Loading...</h2>
      <div className="spinner-border" role="status">
        <span className="sr-only">Loading...</span>
      </div>
    </div>
  );
};

export default Loading;
