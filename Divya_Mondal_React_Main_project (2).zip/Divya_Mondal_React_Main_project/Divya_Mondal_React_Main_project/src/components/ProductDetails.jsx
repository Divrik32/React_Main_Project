import React from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ApiHandler from "../Api/ApiHandler";
import { image } from "../Api/Endpoints";

const ProductDetails = () => {
  const { id } = useParams();

  const { data, error, isLoading } = useQuery({
    queryKey: ["productDetails", id],
    queryFn: () => ApiHandler.fetchProductDetail(id),
    onSuccess: (data) => {
      console.log("Product details fetched successfully:", data);
    },
    onError: (error) => {
      toast.error(`Error fetching product details: ${error.message}`);
    },
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading product details: {error.message}</div>;
  }

  return (<>
    <div className="hero">
    <div className="container">
      <div className="row justify-content-between">
        <div className="col-lg-5">
          <div className="intro-excerpt">
            <h1>Product Details</h1>
          </div>
        </div>
        <div className="col-lg-7">
        </div>
      </div>
    </div>
  </div>
  
    <div className="d-flex flex-column align-items-center" style={{ height: "100vh" }}>
      <Link className="btn btn-success mb-3 mt-5" to="/shop">
        Back to Product List
      </Link>

      <div
        className="card mb-5 p-3 border rounded shadow-sm"
        style={{ width: "350px" }} 
      >
        <img
          src={image(data?.image)}
          alt={data.title}
          className="card-img-top"
          style={{ height: "200px", width: "100%", objectFit: "cover" }}
        />
        <div className="card-body text-center">
          <div className="d-flex align-items-center mb-2">
            <h4 style={{ color: "red", fontSize: "18px", margin: "0" }}>
              Product Title:
            </h4>
            <h5
              className="card-title ms-2" // Bootstrap class for left margin
              style={{ fontWeight: "bold", fontSize: "1.25rem", margin: "0" }}
            >
              {data.title}
            </h5>
          </div>

          <div className="d-flex align-items-center mb-2">
            <h4 style={{ color: "blue", fontSize: "18px", margin: "0" }}>
              Description:
            </h4>
            <p
              className="ms-2"
              style={{ margin: "0", fontSize: "0.9rem", color: "#555" }}
            >
              {data.description}
            </p>
          </div>

          <div className="d-flex align-items-center mb-3">
            <h4 style={{ color: "green", fontSize: "18px", margin: "0" }}>
              Price:
            </h4>
            <strong className="ms-2" style={{ fontSize: "1.25rem", color: "#333" }}>
              $50
            </strong>
          </div>
          
          <div className="d-flex justify-content-center">
            <Link to={`/editProduct/${id}`} className="btn btn-primary mx-1">
              Edit Product
            </Link>
            <Link to={`/productList`} className="btn btn-warning mx-1">
              Add to Cart
            </Link>
          </div>
        </div>
      </div>

      <ToastContainer />
    </div>
    </>);
};

export default ProductDetails;
