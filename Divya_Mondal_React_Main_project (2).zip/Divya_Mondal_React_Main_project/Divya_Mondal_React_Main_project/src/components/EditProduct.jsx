import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ApiHandler from "../Api/ApiHandler";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useNavigate, useParams } from "react-router-dom";
import { Box, Button, TextField, Typography, Paper, Grid } from "@mui/material";

const EditProduct = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();

  // Fetch product by ID
  const { data, isError, isLoading } = useQuery({
    queryKey: ["products", id],
    queryFn: () => ApiHandler.fetchProductDetail(id),
  });

  // Update method
  const { mutate } = useMutation({
    mutationFn: ApiHandler.updateProduct,
    onSuccess: (response) => {
      if (response?.status === 200) {
        toast.success(response?.message, {
          onClose: () => navigate("/shop"),
        });
        queryClient.invalidateQueries({ queryKey: ["products"] });
      } else {
        toast.error(response?.message);
      }
    },
  });

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const [img, setImg] = useState(null);

  const onSubmit = (data) => {
    const formData = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    if (img) {
      formData.append("image", img);
    }
    formData.append("id", id);
    mutate(formData);
  };

  // Show data in the input box
  useEffect(() => {
    if (!isLoading && !isError && data) {
      setValue("title", data.title);
      setValue("description", data.description);
    }
  }, [data, setValue, isLoading, isError]);

  if (isLoading) return <p>Loading...</p>;
  if (isError) return <p>Error loading product details</p>;

  return (
    <>
      <Box sx={{ padding: 4, backgroundColor: "#f5f5f5", minHeight: "100vh" }}>
        <Grid container spacing={2} justifyContent="center">
          <Grid item xs={12} sm={8} md={6}>
            <Paper elevation={3} sx={{ padding: 4 }}>
              <Typography variant="h4" align="center" color="primary" gutterBottom>
                Edit Product
              </Typography>
              <form onSubmit={handleSubmit(onSubmit)}>
                <Box sx={{ marginBottom: 2 }}>
                  <TextField
                    fullWidth
                    label="Title"
                    variant="outlined"
                    {...register("title", { required: true })}
                    error={!!errors.title}
                    helperText={errors.title ? "This field is required" : ""}
                  />
                </Box>
                <Box sx={{ marginBottom: 2 }}>
                  <TextField
                    fullWidth
                    label="Description"
                    variant="outlined"
                    multiline
                    rows={3}
                    {...register("description", { required: true })}
                    error={!!errors.description}
                    helperText={errors.description ? "This field is required" : ""}
                  />
                </Box>
                <Box sx={{ marginBottom: 2 }}>
                  <input
                    type="file"
                    onChange={(e) => setImg(e.target.files[0])}
                    accept="image/*"
                    style={{ display: "none" }}
                    id="image-upload"
                  />
                  <label htmlFor="image-upload">
                    <Button variant="contained" component="span" fullWidth sx={{ backgroundColor: "#4caf50", '&:hover': { backgroundColor: "#388e3c" } }}>
                      Upload Image
                    </Button>
                  </label>
                  {img && (
                    <img
                      style={{ height: "180px", marginTop: "10px" }}
                      src={URL.createObjectURL(img)}
                      alt="Preview"
                      className="upload-img"
                    />
                  )}
                </Box>
                <Button type="submit" variant="contained" fullWidth sx={{ backgroundColor: "#1976d2", '&:hover': { backgroundColor: "#115293" } }}>
                  Update
                </Button>
              </form>
            </Paper>
          </Grid>
        </Grid>
      </Box>
      <ToastContainer />
    </>
  );
};

export default EditProduct;
