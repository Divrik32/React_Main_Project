import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  decreseItem,
  increaseItem,
  removeProduct,
} from "../redux/slice/cartslice";
import { image } from "../Api/Endpoints";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";

const Cart = () => {
  const { cartData } = useSelector((state) => state.cart);
  const dispatch = useDispatch();
  const [isEditing, setIsEditing] = useState(false);

  const removeItem = (id) => dispatch(removeProduct(id));
  const increaseQty = (id) => dispatch(increaseItem(id));
  const decreaseQty = (id) => dispatch(decreseItem(id));

  const totalAmount = cartData
    .map((items) => 50 * items.qty)
    .reduce((a, c) => a + c, 0)
    .toFixed(2);

  const totalItems = cartData
    .map((items) => items.qty)
    .reduce((a, c) => a + c, 0);

  return (
    <div>
      <div className="hero">
        <div className="container">
          <div className="row justify-content-between">
            <div className="col-lg-5">
              <h1>Cart</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="untree_co-section before-footer-section">
        <div className="container">
          <div className="row mb-5">
            <form className="col-md-12" method="post">
              <div className="site-blocks-table">
                <table className="table">
                  <thead>
                    <tr>
                      <th className="product-thumbnail">Image</th>
                      <th className="product-name">Title</th>
                      <th className="product-price">Description</th>
                      <th className="product-price">Price</th>
                      <th className="product-quantity">Quantity</th>
                      <th className="product-remove">Remove</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cartData.map((items) => {
                      const { _id, title, description, qty } = items;
                      return (
                        <tr key={_id}>
                          <td className="product-thumbnail">
                            <img
                              src={image(items.image)}
                              alt="Image"
                              className="img-fluid"
                            />
                          </td>
                          <td className="product-name">
                            <h2 className="h5 text-black">{title}</h2>
                          </td>
                          <td>{description}</td>
                          <td>$50</td>
                          <td>
                            {isEditing ? (
                              <Box
                                sx={{
                                  display: "flex",
                                  alignItems: "center",
                                  maxWidth: 120,
                                  marginLeft: "100px",
                                }}
                              >
                                <Button
                                  variant="outlined"
                                  onClick={() => decreaseQty(_id)}
                                  sx={{ minWidth: "30px", marginRight: "8px" }}
                                >
                                  -
                                </Button>
                                <TextField
                                  value={qty}
                                  variant="outlined"
                                  size="small"
                                  inputProps={{
                                    readOnly: true,
                                    style: { textAlign: "center" },
                                  }}
                                  sx={{ width: "120px", marginRight: "8px" }}
                                />
                                <Button
                                  variant="outlined"
                                  onClick={() => increaseQty(_id)}
                                  sx={{ minWidth: "30px" }}
                                >
                                  +
                                </Button>
                              </Box>
                            ) : (
                              <span>{qty}</span>
                            )}
                          </td>
                          <td>
                            {isEditing && (
                              <Button
                                onClick={() => removeItem(_id)}
                                variant="contained"
                                color="white"
                                size="small"
                              >
                                X
                              </Button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </form>
          </div>
          <div className="row">
            <div className="col-md-6">
              <Button
                variant="outlined"
                size="medium"
                onClick={() => setIsEditing(!isEditing)}
              >
                {isEditing ? "Save Cart" : "Edit Cart"}
              </Button>
              <Button
                variant="outlined"
                size="medium"
                href="/shop"
                style={{ textTransform: "none", marginLeft: "10px" }}
              >
                Continue Shopping
              </Button>
            </div>
            <div className="col-md-6 pl-5">
              <div className="row justify-content-end">
                <div className="col-md-7">
                  <h3 className="text-black h4 text-uppercase">Cart Totals</h3>
                </div>
                <div className="row mb-5">
                  <div className="col-md-6">
                    <span className="text-black">Total Items</span>
                  </div>
                  <div className="col-md-6 text-right">
                    <strong className="text-black">{totalItems}</strong>
                  </div>
                </div>
                <div className="row mb-5">
                  <div className="col-md-6">
                    <span className="text-black">Total Price</span>
                  </div>
                  <div className="col-md-6 text-right">
                    <strong className="text-black">${totalAmount}</strong>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <Button
                      variant="outlined"
                      size="small"
                      href="/checkout"
                      style={{ textTransform: "none" }}
                    >
                      Proceed To Checkout
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
