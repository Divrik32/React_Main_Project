export const baseURL = 'https://wtsacademy.dedicateddevelopers.us/api'

export const endPoint = {
  produts: '/product/list',
  
}