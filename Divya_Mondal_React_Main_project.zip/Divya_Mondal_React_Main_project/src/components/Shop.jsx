import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ApiHandler from "../Api/ApiHandler";
import { image } from "../Api/Endpoints";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate, Link } from "react-router-dom";
import { addProduct } from "../redux/slice/cartslice";
import { useDispatch } from "react-redux";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";

const Shop = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const itemsPerPage = 4;

  // Fetch all products
  const { data, isError, isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: ApiHandler.fetchProducts,
    keepPreviousData: true,
  });

  const deleteMutation = useMutation({
    mutationFn: ({ id }) => ApiHandler.deleteProduct(id),
    onSuccess: () => {
      toast.success("Product deleted successfully");
      queryClient.invalidateQueries(["products"]);
    },
    onError: () => {
      toast.error("Error deleting product");
    },
  });

  // Handle delete
  const handleDelete = (id) => {
    deleteMutation.mutate({ id });
  };

  const handleUpdate = (productId) => {
    navigate(`/editProduct/${productId}`);
  };

  if (isLoading) return <p>Loading...</p>;
  if (isError) return <p>Error loading products</p>;

  const filteredProducts = data.data.filter((product) =>
    product.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const selectedProducts = filteredProducts.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div>
      <div className="hero">
        <div className="container">
          <div className="row justify-content-between">
            <div className="col-lg-5">
              <div className="intro-excerpt">
                <h1>Shop</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div style={{ marginTop: "-40px" }} className="untree_co-section product-section before-footer-section">
        <div className="container">
          <Link className="btn btn-success mb-3" to="/create">
            Create Product
          </Link>
          <h2 className="text-center text-info">Product List</h2>
          <TextField
            variant="outlined"
            placeholder="Search Products..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            style={{
              width: "50%",
              marginBottom: "20px",
            }}
          />

          <div className="row">
            {selectedProducts.map((product) => (
              <div className="col-12 col-md-4 col-lg-3 mb-5" key={product._id}>
                <a className="product-item text-center p-3 border rounded shadow-sm" href="#">
                  {product.image ? (
                    <img
                      src={image(product.image)}
                      alt={product.title}
                      style={{
                        width: "150px",
                        height: "150px",
                        objectFit: "cover",
                        borderRadius: "10px",
                      }}
                    />
                  ) : (
                    "No image available"
                  )}
                  <div className="d-flex text-center align-items-center mb-2">
                    <h4 style={{ fontSize: "15px", color: "black" }}>Product Title:</h4>
                    <h5 className="card-title ms-2" style={{ fontSize: "1rem", color: "black" }}>
                      {product.title}
                    </h5>
                  </div>
                  <div className="d-flex align-items-center mb-2">
                    <h4 style={{ fontSize: "15px", color: "black" }}>Description:</h4>
                    <p className="ms-2" style={{ fontSize: "1rem", color: "black" }}>{product.description}</p>
                  </div>
                  <div className="d-flex align-items-center">
                    <h4 style={{ fontSize: "15px", color: "black" }}>Price:</h4>
                    <p className="ms-2" style={{ fontSize: "1rem", color: "black" }}>$50</p>
                  </div>
                  <div className="d-flex flex-column align-items-center mt-3">
                    <div className="d-flex justify-content-center mb-2">
                      <button className="btn btn-danger mx-1" onClick={() => handleDelete(product._id)}>Delete</button>
                      <button className="btn btn-success mx-1" onClick={() => dispatch(addProduct(product))}>Add to Cart</button>
                    </div>
                    <div className="d-flex justify-content-center">
                      <Link className="btn btn-primary mx-1" style={{ background: "#8080ff", border: "none" }} onClick={() => handleUpdate(product._id)}>Edit</Link>
                      <Link to={`/productDetails/${product._id}`} className="btn btn-warning mx-1">Product Details</Link>
                    </div>
                  </div>
                </a>
              </div>
            ))}
          </div>

          {/* Pagination Controls */}
          <div className="pagination d-flex justify-content-center mt-4">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              style={{
                backgroundColor: currentPage === 1 ? "#ccc" : "#28a745",
                color: "white",
                border: "none",
                padding: "10px 20px",
                margin: "0 5px",
                borderRadius: "5px",
                cursor: currentPage === 1 ? "not-allowed" : "pointer",
                transition: "background-color 0.3s",
              }}
            >
              Previous
            </button>
            <span style={{ alignSelf: "center", margin: "0 10px" }}>{currentPage} of {totalPages}</span>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              style={{
                backgroundColor: currentPage === totalPages ? "#ccc" : "#007bff",
                color: "white",
                border: "none",
                padding: "10px 20px",
                margin: "0 5px",
                borderRadius: "5px",
                cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                transition: "background-color 0.3s",
              }}
            >
              Next
            </button>
          </div>

          <ToastContainer />
        </div>
      </div>
    </div>
  );
};

export default Shop;
