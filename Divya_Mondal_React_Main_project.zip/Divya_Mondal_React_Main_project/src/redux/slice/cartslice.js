import { createSlice } from '@reduxjs/toolkit'

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
     cartData: []
    },
  reducers: {
    //add item
    addProduct(state, action) {
      const existingProduct = state.cartData.some(
        (item) => item._id == action.payload._id
      )
      console.log(existingProduct);

      if (existingProduct) {
        return {
          ...state,
          cartData: state.cartData.map((item) =>
            item._id == action.payload._id ? { ...item, qty: item.qty + 1 } : item
          ),
        }
      }

      return {
        ...state,
        cartData: [...state.cartData, { ...action.payload, qty: 1 }],
      }
    },
    //remove item
    removeProduct(state, action) {
      return {
        ...state,
        cartData: state.cartData.filter((item) => item._id !== action.payload),
      }
    },
    //increase qty
    increaseItem(state, action) {
      state.cartData = state.cartData.filter((item) => {
        return item._id === action.payload ? (item.qty += 1) : item
      })
    },
    //decrease qty
    decreseItem(state, action) {
      state.cartData = state.cartData.filter((item) => {
        return item._id === action.payload ? (item.qty -= 1) : item
      })
    },

  },
})

export const {
  addProduct,
  removeProduct,
  increaseItem,
  decreseItem
} = cartSlice.actions
export const cartReducer = cartSlice.reducer
