import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../redux/slice/authSlice";
import { profile_pic } from "../Api/Endpoints";
import "./Navbar.css"; // Ensure you import your CSS
import { Dropdown } from "react-bootstrap";

const Navbar = () => {
  const dispatch = useDispatch();
  const { isLoggedIn, user, profileImage } = useSelector((state) => state.auth);
  const { cartData } = useSelector((state) => state.cart); // Access cart data from redux
  const [showDropdown, setShowDropdown] = useState(false);

  const handleLogout = () => {
    dispatch(logout());
    setShowDropdown(false);
  };

  const handleToggleDropdown = () => setShowDropdown(!showDropdown);

  const totalItems = cartData.reduce((total, item) => total + item.qty, 0);

  return (
    <nav
      className="custom-navbar navbar navbar-expand-md navbar-dark bg-dark"
      aria-label="Furni navigation bar"
    >
      <div className="container">
        <a className="navbar-brand" href="index.html">
          Product Site<span></span>
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarsFurni"
          aria-controls="navbarsFurni"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarsFurni">
          <ul className="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            {isLoggedIn ? (
              <>
                <li>
                  <Link className="nav-link" to="/create">
                    Create Product
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/shop">
                    Shop
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/about">
                    About us
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/services">
                    Services
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/blog">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/contact">
                    Contact us
                  </Link>
                </li>
                <div className="mt-2 ms-4 d-flex">
                  <li className="nav-item text-white">{user}</li>
                  <li className="nav-item">
                    <img
                      src={profileImage ? profile_pic(profileImage) : "error"}
                      alt="Profile"
                      style={{
                        width: "30px",
                        height: "30px",
                        borderRadius: "50%",
                        cursor: "pointer",
                      }}
                      onClick={handleToggleDropdown}
                    />
                  </li>
                  <Dropdown.Menu
                    show={showDropdown}
                    align="end"
                    className="mt-0"
                    style={{ backgroundColor: "gray" }}
                  >
                    <Dropdown.Item>
                      <i className="bi bi-person-circle"></i> Profile
                    </Dropdown.Item>
                    <Dropdown.Divider />
                    <Dropdown.Item onClick={handleLogout}>
                      <i className="bi bi-box-arrow-right"></i> Logout
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </div>
                <ul className="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
                  <li style={{ position: 'relative' }}>
                    <Link className="nav-link" to="/cart">
                      <img src="images/cart.svg" alt="Cart" />
                      {totalItems > 0 && (
                        <span style={{
                          position: 'absolute',
                          top: '-10px',
                          right: '-10px',
                          background: 'red',
                          color: 'white',
                          borderRadius: '50%',
                          padding: '4px 8px',
                          fontSize: '12px',
                          fontWeight: 'bold',
                          boxShadow: '0 2px 5px rgba(0, 0, 0, 0.3)',
                          border: '2px solid white',
                        }}>
                          {totalItems}
                        </span>
                      )}
                    </Link>
                  </li>
                </ul>
              </>
            ) : (
              <>
                <li>
                  <Link className="nav-link" to="/signup">
                    Signup
                  </Link>
                </li>
                <li>
                  <Link className="nav-link" to="/signin">
                    Signin
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
